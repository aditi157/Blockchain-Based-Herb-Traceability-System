import express from "express"
import { getBatchTrace } from "../controllers/customer.controller.js"

const router = express.Router()

router.get("/batch/:batchCode", getBatchTrace)

export default router
