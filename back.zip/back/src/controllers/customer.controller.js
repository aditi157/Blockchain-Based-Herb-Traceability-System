import prisma from "../config/db.js"
import {
  generateHash,
  buildCollectionCanonical,
  verifySignature
} from "../utils/crypto.utils.js"

export const validateFarmer = async (req, res) => {
  try {
    const { batchCode } = req.body

    const batch = await prisma.manufacturingBatch.findUnique({
      where: { batchCode },
      include: {
        labResult: {
          include: {
            collection: {
              include: { farmer: true }
            }
          }
        }
      }
    })

    if (!batch) {
      return res.status(404).json({ error: "Batch not found" })
    }

    const collection = batch.labResult.collection
    const farmer = collection.farmer

    // 🔁 REBUILD CANONICAL EXACTLY
    const recomputedCanonical = buildCollectionCanonical({
      collectionId: collection.id,
      herbName: collection.herbName,
      quantity: collection.quantity,
      farmerId: collection.farmerId,
      assignedLabId: collection.assignedLabId,
      location: collection.location,
      timestamp: collection.createdAt.toISOString()
    })

    const recomputedHash = generateHash(recomputedCanonical)

    const hashMatch = recomputedHash === collection.hash

    const signatureValid = verifySignature(
      farmer.publicKey,
      collection.hash,
      collection.signature
    )

    res.json({
      hashMatch,
      signatureValid
    })

  } catch (err) {
    console.error(err)
    res.status(500).json({ error: "Server error" })
  }
}

export const getBatchTrace = async (req, res) => {
  try {
    const { batchCode } = req.params

    const batch = await prisma.manufacturingBatch.findUnique({
      where: { batchCode },
      include: {
        manufacturer: true,
        labResult: {
          include: {
            lab: true,
            collection: {
              include: {
                farmer: true
              }
            }
          }
        }
      }
    })

    if (!batch) {
      return res.status(404).json({ error: "Batch not found" })
    }

    res.json(batch)

  } catch (err) {
    console.error(err)
    res.status(500).json({ error: "Server error" })
  }
}
