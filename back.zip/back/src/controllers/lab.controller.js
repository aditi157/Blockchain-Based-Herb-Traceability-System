import prisma from "../config/db.js"
import crypto from "crypto"
import {
  generateHash,
  signHash
} from "../utils/crypto.utils.js"

// ==========================
// CREATE LAB RESULT
// ==========================
export const createLabResult = async (req, res) => {
  try {
    const labId = req.user.id
    const { collectionId, result, remarks, assignedMfgId } = req.body

    // 1️⃣ Get collection
    const collection = await prisma.collection.findUnique({
      where: { id: collectionId }
    })

    if (!collection) {
      return res.status(404).json({ error: "Collection not found" })
    }

    // 2️⃣ Resolve manufacturer UUID (if provided)
    let manufacturerUUID = null

    if (assignedMfgId) {
      const manufacturer = await prisma.organization.findUnique({
        where: { orgCode: assignedMfgId }
      })

      if (!manufacturer) {
        return res.status(400).json({ error: "Manufacturer not found" })
      }

      manufacturerUUID = manufacturer.id
    }

    // 3️⃣ Build canonical string (DO NOT CHANGE ORDER EVER)
    const canonicalData =
      `collectionId:${collectionId}|` +
      `labId:${labId}|` +
      `result:${result}|` +
      `remarks:${remarks || ""}|` +
      `assignedMfgId:${manufacturerUUID || ""}`

    const hash = generateHash(canonicalData)

    const lab = await prisma.organization.findUnique({
      where: { id: labId }
    })

    const signature = signHash(lab.privateKey, hash)

    // 4️⃣ Store result
    const labResult = await prisma.labResult.create({
      data: {
        collectionId,
        result,
        remarks,
        canonicalData,
        hash,
        signature,
        labId,
        assignedMfgId: manufacturerUUID
      }
    })

    res.status(201).json(labResult)

  } catch (err) {
    console.error(err)
    res.status(500).json({ error: "Server error" })
  }
}


// ==========================
// GET PAST TESTS
// ==========================
// export const getPastTests = async (req, res) => {
//   try {
//     const labId = req.user.id

//     const results = await prisma.labResult.findMany({
//       where: { labId },
//       orderBy: { createdAt: "desc" }
//     })

//     res.json(results)

//   } catch (err) {
//     console.error(err)
//     res.status(500).json({ error: "Server error" })
//   }
// }

export const getPastTests = async (req, res) => {
  try {
    const results = await prisma.labResult.findMany({
      where: { labId: req.user.id },
      orderBy: { createdAt: "desc" },
      include: {
        collection: {
          include: {
            farmer: true
          }
        },
        assignedMfg: true
      }
    })

    res.json(results)

  } catch (err) {
    console.error(err)
    res.status(500).json({ error: "Server error" })
  }
}
