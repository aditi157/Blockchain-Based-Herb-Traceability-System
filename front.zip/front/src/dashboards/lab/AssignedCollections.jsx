import { useEffect, useState } from "react"
import LabResultModal from "../../components/LabResultModal"

const AssignedCollections = () => {
  const [collections, setCollections] = useState([])
  const [error, setError] = useState("")
  const [selectedCollection, setSelectedCollection] = useState(null)
  const [decision, setDecision] = useState(null)
  const [remarks, setRemarks] = useState("")
  const [assignedMfg, setAssignedMfg] = useState("")
const [validationResult, setValidationResult] = useState(null)
const [validating, setValidating] = useState(false)

  const token = localStorage.getItem("token")

  const load = async () => {
    try {
      const res = await fetch("http://localhost:5000/api/collections/assigned", {
        headers: { Authorization: `Bearer ${token}` },
        cache: "no-store"
      })
      const data = await res.json()
      if (!res.ok) { setError(data.error || "Failed to fetch"); return }
      setCollections(data)
    } catch (err) {
      console.error(err)
      setError("Server error")
    }
  }

  useEffect(() => { load() }, [])

const handleValidateFarmer = async () => {
  try {
    setValidating(true)
    setValidationResult(null)

    const res = await fetch(
      `http://localhost:5000/api/collections/${selectedCollection.id}/validate`,
      {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }
    )

    const data = await res.json()

    if (!res.ok) {
      setValidationResult({
        valid: false,
        reason: data.error || "Validation failed"
      })
      return
    }

    setValidationResult(data)

  } catch (err) {
    console.error(err)
    setValidationResult({
      valid: false,
      reason: "Server error"
    })
  } finally {
    setValidating(false)
  }
}

  const handleSubmitLabResult = async () => {
  try {
  
    const res = await fetch("http://localhost:5000/api/lab/results", {
  method: "POST",
  headers: {
    "Content-Type": "application/json",
    Authorization: `Bearer ${token}`
  },
  body: JSON.stringify({
    collectionId: selectedCollection.id,
    result: decision,          // PASS or FAIL
    remarks,
    assignedMfgId: assignedMfg
  })
})


    const data = await res.json()

    if (!res.ok) {
      alert(data.error || "Failed to submit result")
      return
    }

    // Close modal after success
    setSelectedCollection(null)

    // Refresh list
    load()

  } catch (err) {
    console.error(err)
    alert("Server error")
  }
}



  return (
    <div className="records-section">
      <h2>Incoming Samples</h2>

      {error && <p className="error-text">{error}</p>}

      {collections.length === 0 && !error && (
        <p className="muted-text">No collections assigned to your lab yet.</p>
      )}

      <table className="records-table">
        <thead>
          <tr>
            <th>Herb</th>
            <th>Quantity</th>
            <th>Farmer ID</th>
            <th>Assigned Lab</th>
            <th>Location</th>
            <th>Created At</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {collections.map((c) => (
            <tr key={c.id}>
              <td>{c.herbName}</td>
              <td>{c.quantity} kg</td>
              <td>{c.farmer?.orgCode || "—"}</td>
              <td>{c.assignedLabId || "—"}</td>
              <td>{c.location || "—"}</td>
              <td>{new Date(c.createdAt).toLocaleString()}</td>
              <td>
                <button
  className="btn-secondary"
  onClick={() => {
    setSelectedCollection(c)
    setDecision(null)
    setRemarks("")
    setAssignedMfg("")
  }}
>

                  Add Result
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {selectedCollection && (
  <div className="modal-backdrop" onClick={() => setSelectedCollection(null)}>
    <div
      className="modal-inspection"
      onClick={(e) => e.stopPropagation()}
    >

      {/* LEFT PANEL */}
      <div className="inspection-left">
        <h3>Collection Inspection</h3>

        <div className="info-block">
          <label>Collection ID</label>
          <span>{selectedCollection.id}</span>
        </div>

        <div className="info-block">
          <label>Herb</label>
          <span>{selectedCollection.herbName}</span>
        </div>

        <div className="info-block">
          <label>Quantity</label>
          <span>{selectedCollection.quantity} kg</span>
        </div>

        <div className="info-block">
          <label>Farmer</label>
          <span>{selectedCollection.farmer?.name}</span>
        </div>

        <div className="info-block">
          <label>Farmer ID</label>
          <span>{selectedCollection.farmer?.orgCode}</span>
        </div>

        <div className="info-block">
          <label>Assigned Lab</label>
          <span>{selectedCollection.assignedLabId}</span>
        </div>

        <div className="info-block">
          <label>Created At</label>
          <span>
            {new Date(selectedCollection.createdAt).toLocaleString()}
          </span>
        </div>

        <button
  className="ghost-btn"
  onClick={handleValidateFarmer}
>
  {validating ? "Validating..." : "Validate Farmer Signature"}
</button>
{validationResult && (
  <div
    className={`validation-result ${
      validationResult.valid ? "valid" : "invalid"
    }`}
  >
    <div className="validation-icon">
      {validationResult.valid ? "✔" : "✖"}
    </div>

    <h2>
      {validationResult.valid ? "Record Valid" : "Record Compromised"}
    </h2>

    {!validationResult.valid && (
      <p className="validation-message">
        {validationResult.reason}
      </p>
    )}
  </div>
)}


      </div>

      {/* RIGHT PANEL */}
      <div className="inspection-right">

        <div className="decision-header">
          <h3>Lab Decision</h3>
          <button
            className="close-btn"
            onClick={() => setSelectedCollection(null)}
          >
            ✕
          </button>
        </div>

        <div className="decision-toggle">
          <button
            className={`pill pass ${decision === "PASS" ? "active" : ""}`}
            onClick={() => setDecision("PASS")}
          >
            PASS
          </button>

          <button
            className={`pill fail ${decision === "FAIL" ? "active" : ""}`}
            onClick={() => setDecision("FAIL")}
          >
            FAIL
          </button>
        </div>

        <textarea
          placeholder="Remarks (optional)"
          value={remarks}
          onChange={(e) => setRemarks(e.target.value)}
        />

        <input
          type="text"
          placeholder="Assign Manufacturer ID (optional)"
          value={assignedMfg}
          onChange={(e) => setAssignedMfg(e.target.value)}
        />

        <button
          className="submit-btn"
          disabled={!decision}
          onClick={handleSubmitLabResult}
        >
          Submit Lab Result
        </button>

      </div>
    </div>
  </div>
)}

    </div>
  )
}

export default AssignedCollections