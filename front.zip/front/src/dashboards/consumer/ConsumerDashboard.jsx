import { useState } from "react"
import Sidebar from "../../components/Sidebar"
import SavedRecords from "./SavedRecords"
import VerifyView from "./VerifyView"


const CustomerDashboard = () => {
  const [activeTab, setActiveTab] = useState("verify")
  const [batchCode, setBatchCode] = useState("")
  const [data, setData] = useState(null)
  const [error, setError] = useState("")

  const handleLogout = () => {
    localStorage.removeItem("token")
    localStorage.removeItem("organization")
    window.location.href = "/login"
  }

  const [savedRecords, setSavedRecords] = useState(() => {
  const stored = localStorage.getItem("savedRecords")
  return stored ? JSON.parse(stored) : []
})

const handleSaveRecord = () => {
  if (!data) return

  const recordName = prompt("Enter a name for this record:")
  if (!recordName) return

  const newRecord = {
    id: Date.now(),
    name: recordName,
    batchCode: data.batchCode,
    dateSaved: new Date().toISOString(),
    data
  }

  const updated = [...savedRecords, newRecord]
  setSavedRecords(updated)
  localStorage.setItem("savedRecords", JSON.stringify(updated))

  alert("Record saved successfully!")
}

  const fetchBatch = async () => {
    try {
      setError("")
      setData(null)

      const res = await fetch(
        `http://localhost:5000/api/customer/batch/${batchCode}`
      )

      const result = await res.json()

      if (!res.ok) {
        setError(result.error || "Batch not found")
        return
      }

      setData(result)

    } catch (err) {
      console.error(err)
      setError("Server error")
    }
  }

  return (
    <div className="dashboard-layout">

      <Sidebar
        role="Consumer"
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onLogout={handleLogout}
      />

      <div className="dashboard-content">

        {activeTab === "verify" && (
          <div className="records-section">
            <h2>Product Traceability</h2>

            {/* SEARCH */}
            <div className="search-bar">
              <input
                type="text"
                placeholder="Enter Batch Code (e.g. BATCH-001)"
                value={batchCode}
                onChange={(e) => setBatchCode(e.target.value)}
              />
              <button className="btn-secondary" onClick={fetchBatch}>
                Verify Batch
              </button>
            </div>

            {error && <p className="error-text">{error}</p>}

            {data && (
              <div className="trace-layout">

                {/* FARMER */}
                <div className="trace-card">
                  <h3>Farmer</h3>
                  <div className="info-block">
                    <label>Name</label>
                    <span>{data.labResult.collection.farmer.name}</span>
                  </div>
                  <div className="info-block">
                    <label>Farmer ID</label>
                    <span>{data.labResult.collection.farmer.orgCode}</span>
                  </div>
                  <div className="info-block">
                    <label>Location</label>
                    <span>{data.labResult.collection.location}</span>
                  </div>
                  <div className="info-block">
                    <label>Herb</label>
                    <span>{data.labResult.collection.herbName}</span>
                  </div>
                  <div className="info-block">
                    <label>Quantity</label>
                    <span>{data.labResult.collection.quantity} kg</span>
                  </div>
                </div>

                {/* LAB */}
                <div className="trace-card">
                  <h3>Laboratory</h3>
                  <div className="info-block">
                    <label>Lab</label>
                    <span>{data.labResult.lab.name}</span>
                  </div>
                  <div className="info-block">
                    <label>Lab ID</label>
                    <span>{data.labResult.lab.orgCode}</span>
                  </div>
                  <div className="info-block">
                    <label>Result</label>
                    <span className={`pill ${data.labResult.result === "PASS" ? "pass active" : "fail active"}`}>
                      {data.labResult.result}
                    </span>
                  </div>
                  <div className="info-block">
                    <label>Remarks</label>
                    <span>{data.labResult.remarks || "—"}</span>
                  </div>
                </div>

                {/* MANUFACTURER */}
                <div className="trace-card">
                  <h3>Manufacturer</h3>
                  <div className="info-block">
                    <label>Name</label>
                    <span>{data.manufacturer.name}</span>
                  </div>
                  <div className="info-block">
                    <label>Manufacturer ID</label>
                    <span>{data.manufacturer.orgCode}</span>
                  </div>
                  <div className="info-block">
                    <label>Batch Name</label>
                    <span>{data.batchName}</span>
                  </div>
                  <div className="info-block">
                    <label>Final Product</label>
                    <span>{data.finalProductQuantity} g</span>
                  </div>
                  <div className="info-block">
                    <label>Expiry</label>
                    <span>
                      {new Date(data.expiryDate).toLocaleDateString()}
                    </span>
                  </div>
                </div>

                {/* VALIDATION BUTTONS */}
                <div className="trace-actions">
                  <h3>Integrity Verification</h3>

                  <button
  className="btn-secondary"
  onClick={async () => {
    const res = await fetch(
      "http://localhost:5000/api/customer/validate/farmer",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ batchCode: data.batchCode })
      }
    )

    const result = await res.json()

    alert(
      `Hash Match: ${result.hashMatch}\nSignature Valid: ${result.signatureValid}`
    )
  }}
>
  Validate Farmer Records
</button>


                  <button className="btn-secondary">
                    Validate Lab Records
                  </button>

                  <button className="btn-secondary">
                    Validate Manufacturer Records
                  </button>
                  <button className="btn-secondary" onClick={handleSaveRecord}>
                    Save Record
                  </button>

                </div>

              </div>
            )}

          </div>
        )}
        

      </div>
    </div>
  )
}

export default CustomerDashboard

